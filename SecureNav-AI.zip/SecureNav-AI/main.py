"""
main.py
───────
SecureNav AI — Full End-to-End Pipeline

Steps
─────
  1.  Simulate clean GNSS data
  2.  Inject spoofing, jamming, drift attacks
  3.  Extract ML features
  4.  Save synthetic dataset to data/
  5.  Train Random Forest, SVM, MLP
  6.  Cross-validate each model
  7.  Evaluate on held-out test set
  8.  Train Isolation Forest anomaly detector
  9.  Generate ensemble threat scores
  10. Run alert system on test set
  11. Save all results and plots to results/
  12. Print final comparison table
"""

import sys
import time
import warnings
import numpy as np
import pandas as pd
from pathlib import Path
from sklearn.model_selection import train_test_split

warnings.filterwarnings("ignore")

# ── Project root on path ────────────────────────────────────────
ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT))

from src.gnss_simulator     import GNSSSimulator, epochs_to_dataframe
from src.spoofing_simulator import SpoofingSimulator
from src.jamming_simulator  import JammingSimulator
from src.drift_simulator    import DriftSimulator
from src.feature_extraction import extract_features, FEATURE_COLUMNS, CLASS_NAMES
from src.model_training     import (
    build_random_forest, build_svm, build_mlp,
    prepare_data, cross_validate_model, train_model,
    save_model, get_feature_importances, ALL_MODELS,
)
from src.anomaly_detection  import (
    fit_anomaly_detector_from_df, ensemble_anomaly_score,
)
from src.evaluation         import (
    compute_metrics, compute_roc, summarise_cv,
    compare_models, save_report,
)
from src.alert_system       import (
    AlertGenerator, process_batch, print_alert_summary,
)
from src.visualization      import (
    plot_signal_overview, plot_confusion_matrix,
    plot_feature_importance, plot_roc_curves,
    plot_pca_scatter, plot_position_trajectory,
    plot_model_comparison, plot_anomaly_scores,
    save_dashboard,
)


# ──────────────────────────────────────────────────────────────
# Configuration
# ──────────────────────────────────────────────────────────────
CFG = {
    "n_epochs_per_class" : 2000,    # epochs generated per class
    "test_size"          : 0.20,
    "cv_folds"           : 5,
    "seed"               : 42,
    "data_dir"           : ROOT / "data",
    "results_dir"        : ROOT / "results",
    "models_dir"         : ROOT / "results" / "models",
    "alert_log"          : ROOT / "results" / "alerts.json",
}

for d in (CFG["data_dir"], CFG["results_dir"], CFG["models_dir"]):
    d.mkdir(parents=True, exist_ok=True)


# ──────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────
def _banner(msg: str) -> None:
    width = 68
    print(f"\n{'═'*width}")
    print(f"  {msg}")
    print(f"{'═'*width}")


def _step(n, msg: str) -> None:
    label = f"{n:02d}" if isinstance(n, int) else str(n)
    print(f"\n  [{label}] {msg}")


# ──────────────────────────────────────────────────────────────
# STEP 1–2: Data generation
# ──────────────────────────────────────────────────────────────
def generate_dataset(n: int, seed: int) -> pd.DataFrame:
    _banner("DATA GENERATION")
    n_each = n

    # Normal
    _step(1, f"Simulating {n_each} NORMAL epochs …")
    sim_normal  = GNSSSimulator(seed=seed)
    eps_normal  = sim_normal.generate_dataset(n_each)

    # Spoofing
    _step(2, f"Simulating {n_each} SPOOFING epochs …")
    sim_base_s  = GNSSSimulator(seed=seed + 1)
    base_s      = sim_base_s.generate_dataset(n_each)
    spoofer     = SpoofingSimulator(mode="mixed", seed=seed + 10)
    eps_spoof   = spoofer.generate_dataset(base_s)

    # Jamming
    _step(3, f"Simulating {n_each} JAMMING epochs …")
    sim_base_j  = GNSSSimulator(seed=seed + 2)
    base_j      = sim_base_j.generate_dataset(n_each)
    jammer      = JammingSimulator(mode="mixed", seed=seed + 20)
    eps_jam     = jammer.generate_dataset(base_j)

    # Drift
    _step(4, f"Simulating {n_each} DRIFT epochs …")
    sim_base_d  = GNSSSimulator(seed=seed + 3)
    base_d      = sim_base_d.generate_dataset(n_each)
    drifter     = DriftSimulator(mode="mixed", seed=seed + 30)
    eps_drift   = drifter.generate_dataset(base_d)

    # Feature extraction
    _step(5, "Extracting features …")
    all_epochs = eps_normal + eps_spoof + eps_jam + eps_drift

    df_feat = extract_features(all_epochs)

    # Attach lat/lon/alt/timestamp from raw epochs for visualisation
    raw_df = epochs_to_dataframe(all_epochs)
    for col in ["lat", "lon", "alt", "timestamp"]:
        if col in raw_df.columns and col not in df_feat.columns:
            df_feat[col] = raw_df[col].values

    print(f"      Dataset shape: {df_feat.shape}")
    print(f"      Class balance:\n{df_feat['label'].value_counts().to_string()}")

    path = CFG["data_dir"] / "gnss_dataset.csv"
    df_feat.to_csv(path, index=False)
    print(f"      Saved → {path}")

    return df_feat


# ──────────────────────────────────────────────────────────────
# STEP 3: Train / evaluate models
# ──────────────────────────────────────────────────────────────
def train_and_evaluate(df: pd.DataFrame, seed: int):
    _banner("MODEL TRAINING & EVALUATION")

    X, y, le = prepare_data(df, seed=seed)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=CFG["test_size"], stratify=y, random_state=seed
    )
    print(f"\n  Train: {len(X_train):,}   Test: {len(X_test):,}")

    pipelines = {
        "random_forest": build_random_forest(seed=seed),
        "svm"          : build_svm(seed=seed),
        "mlp"          : build_mlp(seed=seed),
    }

    trained    = {}
    cv_results = {}
    metrics    = {}
    roc_data   = {}

    for name, pipe in pipelines.items():
        _step("T", f"Cross-validating {name.upper()} (k={CFG['cv_folds']}) …")
        t0 = time.time()
        cv = cross_validate_model(pipe, X_train, y_train,
                                  k=CFG["cv_folds"], seed=seed)
        cv_results[name] = cv
        cv_df = summarise_cv(cv, name)
        print(f"      CV Accuracy : {cv['accuracy']['mean']:.4f} ± {cv['accuracy']['std']:.4f}")
        print(f"      CV Macro F1 : {cv['f1_macro']['mean']:.4f} ± {cv['f1_macro']['std']:.4f}")

        _step("T", f"Training {name.upper()} on full train set …")
        pipe = train_model(pipe, X_train, y_train)
        trained[name] = pipe
        save_model(pipe, CFG["models_dir"] / f"{name}.joblib")

        # Test set evaluation
        y_pred = pipe.predict(X_test)
        m = compute_metrics(y_pred=y_pred, y_true=y_test,
                            class_names=le.classes_.tolist())
        metrics[name] = m
        print(f"      Test Accuracy: {m['accuracy']:.4f}   Macro F1: {m['macro_f1']:.4f}")
        print(f"      Time: {time.time()-t0:.1f}s")

        save_report(m, name, cv_df, CFG["results_dir"])

        # ROC (needs predict_proba)
        if hasattr(pipe, "predict_proba"):
            y_prob = pipe.predict_proba(X_test)
            roc_data[name] = compute_roc(y_test, y_prob,
                                         class_names=le.classes_.tolist())

    return trained, metrics, roc_data, cv_results, le, X_train, X_test, y_train, y_test


# ──────────────────────────────────────────────────────────────
# STEP 4: Anomaly detection
# ──────────────────────────────────────────────────────────────
def run_anomaly_detection(df: pd.DataFrame, X_test: np.ndarray,
                          y_test: np.ndarray, le):
    _banner("ANOMALY DETECTION  (Isolation Forest)")
    _step(6, "Fitting Isolation Forest on NORMAL samples …")

    detector = fit_anomaly_detector_from_df(df, seed=42)
    scores   = detector.score_samples(X_test)
    flags    = detector.predict(X_test)

    n_anomalies = int(np.sum(flags == -1))
    n_total     = len(flags)
    print(f"      Anomalies detected: {n_anomalies} / {n_total}  ({n_anomalies/n_total*100:.1f}%)")

    return detector, scores


# ──────────────────────────────────────────────────────────────
# STEP 5: Alerts
# ──────────────────────────────────────────────────────────────
def run_alerts(trained, metrics, detector, df_test, X_test,
               y_test, anomaly_scores, le, best_model_name: str):
    _banner("ALERT GENERATION")
    _step(7, "Running alert system on test set …")

    pipe      = trained[best_model_name]
    y_pred    = pipe.predict(X_test)
    y_prob    = pipe.predict_proba(X_test) if hasattr(pipe, "predict_proba") \
                else np.eye(len(le.classes_))[y_pred]

    ens_scores = ensemble_anomaly_score(y_prob, anomaly_scores,
                                        normal_class_idx=list(le.classes_).index("NORMAL")
                                        if "NORMAL" in le.classes_ else 0)

    generator = AlertGenerator(
        cooldown_s   = 0,     # no cooldown in batch evaluation
        min_severity = "INFO",
        log_path     = CFG["alert_log"],
    )

    alerts = process_batch(
        predictions     = y_pred,
        probabilities   = y_prob,
        anomaly_scores  = anomaly_scores,
        ensemble_scores = ens_scores,
        feature_df      = df_test.reset_index(drop=True),
        class_names     = list(le.classes_),
        generator       = generator,
        verbose         = False,
    )

    print_alert_summary(alerts)
    return alerts, y_pred, y_prob, ens_scores


# ──────────────────────────────────────────────────────────────
# STEP 6: Visualisations
# ──────────────────────────────────────────────────────────────
def generate_plots(df, metrics, roc_data, trained, comparison_df,
                   X_test, y_test, anomaly_scores, le):
    _banner("VISUALISATION")

    _step(8, "Signal overview …")
    plot_signal_overview(df, save_path=CFG["results_dir"] / "signal_overview.png")

    _step(9, "Position trajectory …")
    plot_position_trajectory(df, save_path=CFG["results_dir"] / "position_trajectory.png")

    _step(10, "PCA scatter …")
    X_feat = df[FEATURE_COLUMNS].fillna(0).values
    y_int  = df["label"].map({c: i for i, c in enumerate(CLASS_NAMES)}).fillna(0).astype(int).values
    plot_pca_scatter(X_feat, y_int,
                     save_path=CFG["results_dir"] / "pca_scatter.png")

    _step(11, "Confusion matrices …")
    best = "random_forest"
    cm = metrics[best]["confusion_matrix"]
    plot_confusion_matrix(cm,
                          class_names=metrics[best]["class_names_present"],
                          save_path=CFG["results_dir"] / "confusion_matrix.png")
    plot_confusion_matrix(cm,
                          class_names=metrics[best]["class_names_present"],
                          normalised=True,
                          save_path=CFG["results_dir"] / "confusion_matrix_norm.png")

    _step(12, "Feature importance …")
    imp = get_feature_importances(trained["random_forest"])
    if not imp.empty:
        plot_feature_importance(imp, save_path=CFG["results_dir"] / "feature_importance.png")

    _step(13, "ROC curves …")
    if "random_forest" in roc_data:
        plot_roc_curves(roc_data["random_forest"],
                        save_path=CFG["results_dir"] / "roc_curves.png")

    _step(14, "Anomaly scores …")
    y_labels_str = np.array([le.classes_[i] for i in y_test])
    plot_anomaly_scores(anomaly_scores, y_labels_str,
                        save_path=CFG["results_dir"] / "anomaly_scores.png")

    _step(15, "Model comparison …")
    plot_model_comparison(comparison_df,
                          save_path=CFG["results_dir"] / "model_comparison.png")

    _step(16, "Dashboard …")
    imp_series = get_feature_importances(trained["random_forest"])
    save_dashboard(df, metrics["random_forest"], imp_series, comparison_df,
                   save_path=CFG["results_dir"] / "dashboard.png")


# ──────────────────────────────────────────────────────────────
# STEP 7: Final comparison
# ──────────────────────────────────────────────────────────────
def print_final_comparison(metrics: dict) -> pd.DataFrame:
    _banner("FINAL MODEL COMPARISON")
    comp = compare_models(metrics)
    comp.to_csv(CFG["results_dir"] / "model_comparison.csv", index=False)

    print(f"\n  {'Model':<20} {'Accuracy':>10} {'Macro F1':>10} {'Weighted F1':>12}")
    print(f"  {'─'*55}")
    for _, row in comp.iterrows():
        marker = " ◀ best" if row.name == 0 else ""
        print(f"  {row['model']:<20} {row['accuracy']:>10.4f} "
              f"{row['macro_f1']:>10.4f} {row['weighted_f1']:>12.4f}{marker}")
    return comp


# ──────────────────────────────────────────────────────────────
# Main
# ──────────────────────────────────────────────────────────────
def main():
    t_start = time.time()
    _banner("SecureNav AI — GNSS Spoofing & Jamming Detection")
    print(f"  Config: {CFG['n_epochs_per_class']} epochs/class  |  "
          f"test={CFG['test_size']}  |  seed={CFG['seed']}")

    # 1. Generate
    df = generate_dataset(CFG["n_epochs_per_class"], CFG["seed"])

    # 2. Train + evaluate
    (trained, metrics, roc_data, cv_results, le,
     X_train, X_test, y_train, y_test) = train_and_evaluate(df, CFG["seed"])

    # 3. Anomaly detection
    detector, anomaly_scores = run_anomaly_detection(df, X_test, y_test, le)

    # 4. Identify best model for alerts
    comparison_df  = compare_models(metrics)
    best_model_name = comparison_df.iloc[0]["model"]
    print(f"\n  Best model: {best_model_name.upper()}")

    # 5. Build test feature df (with lat/lon)
    df_feat_full = df.copy()
    n_test       = len(X_test)
    df_test      = df_feat_full.tail(n_test).copy()

    # 6. Alerts
    alerts, y_pred, y_prob, ens_scores = run_alerts(
        trained, metrics, detector, df_test,
        X_test, y_test, anomaly_scores, le, best_model_name,
    )

    # 7. Plots
    generate_plots(df, metrics, roc_data, trained, comparison_df,
                   X_test, y_test, anomaly_scores, le)

    # 8. Summary
    comp = print_final_comparison(metrics)

    elapsed = time.time() - t_start
    _banner(f"Pipeline complete in {elapsed:.1f}s")
    print(f"  Results saved to: {CFG['results_dir']}/")
    print(f"  Models  saved to: {CFG['models_dir']}/")
    print(f"  Alert log       : {CFG['alert_log']}\n")


if __name__ == "__main__":
    main()
