"""
model_training.py
─────────────────
Trains, tunes, and persists classification models for GNSS threat detection.

Models
──────
  1. RandomForestClassifier  – ensemble of decision trees; excellent baseline
  2. SVC (RBF kernel)        – maximum-margin classifier; good on mid-scale data
  3. MLPClassifier           – feed-forward neural network; captures non-linearity

Pipeline
────────
  Raw DataFrame → StandardScaler → Classifier → Predictions
  Cross-validation (StratifiedKFold, k=5) is run before final fit.
"""

import numpy as np
import pandas as pd
import joblib
from pathlib import Path
from typing import Dict, Tuple, Any

from sklearn.ensemble         import RandomForestClassifier
from sklearn.svm              import SVC
from sklearn.neural_network   import MLPClassifier
from sklearn.preprocessing    import StandardScaler, LabelEncoder
from sklearn.pipeline         import Pipeline
from sklearn.model_selection  import StratifiedKFold, cross_validate
from sklearn.utils            import shuffle

from src.feature_extraction   import FEATURE_COLUMNS, TARGET_COLUMN, CLASS_NAMES


# ──────────────────────────────────────────────────────────────
# Model Definitions
# ──────────────────────────────────────────────────────────────
def build_random_forest(n_estimators: int = 300, seed: int = 42) -> Pipeline:
    return Pipeline([
        ("scaler", StandardScaler()),
        ("clf", RandomForestClassifier(
            n_estimators     = n_estimators,
            max_depth        = None,
            min_samples_leaf = 2,
            max_features     = "sqrt",
            class_weight     = "balanced",
            n_jobs           = -1,
            random_state     = seed,
        )),
    ])


def build_svm(C: float = 10.0, gamma: str = "scale", seed: int = 42) -> Pipeline:
    return Pipeline([
        ("scaler", StandardScaler()),
        ("clf", SVC(
            C            = C,
            kernel       = "rbf",
            gamma        = gamma,
            class_weight = "balanced",
            probability  = True,       # needed for ROC curves
            random_state = seed,
        )),
    ])


def build_mlp(hidden_layers: Tuple = (256, 128, 64), seed: int = 42) -> Pipeline:
    return Pipeline([
        ("scaler", StandardScaler()),
        ("clf", MLPClassifier(
            hidden_layer_sizes  = hidden_layers,
            activation          = "relu",
            solver              = "adam",
            alpha               = 1e-4,
            batch_size          = 128,
            learning_rate       = "adaptive",
            learning_rate_init  = 1e-3,
            max_iter            = 300,
            early_stopping      = True,
            validation_fraction = 0.1,
            n_iter_no_change    = 15,
            random_state        = seed,
        )),
    ])


ALL_MODELS: Dict[str, Pipeline] = {
    "random_forest" : build_random_forest(),
    "svm"           : build_svm(),
    "mlp"           : build_mlp(),
}


# ──────────────────────────────────────────────────────────────
# Data preparation
# ──────────────────────────────────────────────────────────────
def prepare_data(df: pd.DataFrame, seed: int = 42) -> Tuple[np.ndarray, np.ndarray, LabelEncoder]:
    """
    Split a feature DataFrame into X (numpy) and y (integer labels).

    Returns
    -------
    X         : (n_samples, n_features) float array
    y         : (n_samples,) int array
    le        : fitted LabelEncoder (to decode predictions later)
    """
    df = shuffle(df, random_state=seed).reset_index(drop=True)

    # Fill any NaN that slipped through
    feature_df = df[FEATURE_COLUMNS].fillna(0.0)
    X = feature_df.values.astype(np.float64)

    le = LabelEncoder()
    le.fit(CLASS_NAMES)          # fit on all known classes for consistency
    y  = le.transform(df[TARGET_COLUMN].values)

    return X, y, le


# ──────────────────────────────────────────────────────────────
# Cross-validation
# ──────────────────────────────────────────────────────────────
def cross_validate_model(
    pipeline   : Pipeline,
    X          : np.ndarray,
    y          : np.ndarray,
    k          : int = 5,
    seed       : int = 42,
) -> Dict[str, Any]:
    """
    Run stratified k-fold cross-validation.

    Returns dict with mean ± std for accuracy, precision, recall, f1.
    """
    cv = StratifiedKFold(n_splits=k, shuffle=True, random_state=seed)
    scoring = ["accuracy", "f1_macro", "precision_macro", "recall_macro"]

    cv_results = cross_validate(pipeline, X, y, cv=cv, scoring=scoring,
                                return_train_score=False, n_jobs=-1)

    summary = {}
    for metric in scoring:
        key    = f"test_{metric}"
        scores = cv_results[key]
        summary[metric] = {
            "scores" : scores.tolist(),
            "mean"   : float(np.mean(scores)),
            "std"    : float(np.std(scores)),
        }
    return summary


# ──────────────────────────────────────────────────────────────
# Training
# ──────────────────────────────────────────────────────────────
def train_model(
    pipeline   : Pipeline,
    X_train    : np.ndarray,
    y_train    : np.ndarray,
) -> Pipeline:
    """Fit the pipeline on training data."""
    pipeline.fit(X_train, y_train)
    return pipeline


# ──────────────────────────────────────────────────────────────
# Persistence
# ──────────────────────────────────────────────────────────────
def save_model(pipeline: Pipeline, path: str | Path) -> None:
    """Save a trained pipeline with joblib."""
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(pipeline, path)
    print(f"  [✓] Model saved → {path}")


def load_model(path: str | Path) -> Pipeline:
    """Load a saved pipeline."""
    return joblib.load(path)


# ──────────────────────────────────────────────────────────────
# Feature importance (RF only)
# ──────────────────────────────────────────────────────────────
def get_feature_importances(pipeline: Pipeline) -> pd.Series:
    """
    Return feature importances for a RandomForest pipeline.
    Returns an empty Series for other model types.
    """
    clf = pipeline.named_steps.get("clf")
    if hasattr(clf, "feature_importances_"):
        return pd.Series(
            clf.feature_importances_,
            index=FEATURE_COLUMNS,
        ).sort_values(ascending=False)
    return pd.Series(dtype=float)
