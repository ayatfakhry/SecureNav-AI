"""
spoofing_simulator.py
─────────────────────
Injects GNSS spoofing attacks into clean GNSSEpoch streams.

Supports three attack modes:
  1. MEACONING   – Relay + re-broadcast authentic signals with time delay
  2. FALSE_POS   – Craft counterfeit signals placing receiver at attacker location
  3. GRADUAL     – Slowly deviate position to avoid sudden-jump detectors

All modes manipulate the epoch data in-place (or return modified copies),
producing epochs labelled "SPOOFING".
"""

import copy
import numpy as np
from typing import List, Optional

from src.gnss_simulator import GNSSEpoch, SatelliteMeasurement, L1_WAVELENGTH, SPEED_OF_LIGHT


# ──────────────────────────────────────────────
# Spoofing parameters
# ──────────────────────────────────────────────
class SpoofingConfig:
    # Meaconing
    MEACONING_DELAY_S         = 0.05    # 50 ms relay delay
    MEACONING_PHASE_NOISE_STD = 0.15   # cycles

    # False position
    FALSE_POS_OFFSET_LAT  = 0.01        # degrees (~1.1 km)
    FALSE_POS_OFFSET_LON  = 0.01
    FALSE_POS_ALT_OFFSET  = 50.0       # metres
    FALSE_POS_SNR_BOOST   = 4.0        # dB-Hz (spoofed signals often stronger)

    # Gradual drift injection
    GRADUAL_RATE_DEG      = 0.0002     # deg per epoch
    GRADUAL_ALT_RATE      = 1.0        # m per epoch

    # Common: slightly elevated SNR variance
    SPOOF_SNR_STD_INFLATE = 2.5


# ──────────────────────────────────────────────
# Core spoofing functions
# ──────────────────────────────────────────────
def _inject_meaconing(epoch: GNSSEpoch, rng: np.random.Generator, cfg: SpoofingConfig) -> GNSSEpoch:
    """
    Meaconing: replay authentic signals with a fixed delay.
    Effect: pseudoranges increase by delay*c, phase coherence disrupted.
    """
    ep = copy.deepcopy(epoch)
    delay_m = cfg.MEACONING_DELAY_S * SPEED_OF_LIGHT

    for sat in ep.satellites:
        sat.pseudorange_m      += delay_m + float(rng.normal(0.0, 15.0))
        sat.carrier_phase_cycles += float(rng.normal(0.0, cfg.MEACONING_PHASE_NOISE_STD))
        sat.snr_db_hz           = np.clip(
            sat.snr_db_hz + float(rng.normal(1.5, cfg.SPOOF_SNR_STD_INFLATE)), 15.0, 58.0
        )
        # Doppler slightly off due to relay
        sat.doppler_hz += float(rng.normal(0.0, 30.0))

    # Receiver position appears shifted by relay artefact
    ep.lat  += float(rng.normal(0.0, 5e-5))
    ep.lon  += float(rng.normal(0.0, 5e-5))
    ep.clock_bias_m += delay_m * 0.3
    ep.label = "SPOOFING"
    return ep


def _inject_false_position(epoch: GNSSEpoch, rng: np.random.Generator, cfg: SpoofingConfig) -> GNSSEpoch:
    """
    False Position Injection: counterfeit signals force receiver
    to compute an attacker-chosen position.
    """
    ep = copy.deepcopy(epoch)

    # Teleport receiver to false location
    ep.lat += cfg.FALSE_POS_OFFSET_LAT + float(rng.normal(0.0, 1e-4))
    ep.lon += cfg.FALSE_POS_OFFSET_LON + float(rng.normal(0.0, 1e-4))
    ep.alt += cfg.FALSE_POS_ALT_OFFSET + float(rng.normal(0.0, 5.0))

    # Forged signals: higher power, lower PDOP (attacker optimises geometry)
    ep.pdop = np.clip(ep.pdop * 0.6 + float(rng.normal(0.0, 0.3)), 1.0, 5.0)

    for sat in ep.satellites:
        sat.snr_db_hz          = np.clip(
            sat.snr_db_hz + cfg.FALSE_POS_SNR_BOOST + float(rng.normal(0.0, 1.5)), 20.0, 58.0
        )
        # Pseudoranges recomputed to match false location (inconsistency with true clock)
        sat.pseudorange_m     += float(rng.normal(0.0, 50.0))
        sat.carrier_phase_cycles = sat.pseudorange_m / L1_WAVELENGTH + float(rng.normal(0.0, 0.5))
        sat.doppler_hz        = float(rng.normal(0.0, 20.0))  # Near-zero (stationary spoofer)

    ep.clock_bias_m += float(rng.normal(200.0, 30.0))  # Large clock anomaly
    ep.label = "SPOOFING"
    return ep


class GradualSpoofer:
    """
    Stateful gradual spoofing: slowly drags receiver position to
    attacker target over many epochs to evade sudden-jump detectors.
    """

    def __init__(self, cfg: SpoofingConfig = None, seed: int = 0):
        self.cfg        = cfg or SpoofingConfig()
        self.rng        = np.random.default_rng(seed)
        self._accum_lat = 0.0
        self._accum_lon = 0.0
        self._accum_alt = 0.0

    def inject(self, epoch: GNSSEpoch) -> GNSSEpoch:
        ep = copy.deepcopy(epoch)

        self._accum_lat += self.cfg.GRADUAL_RATE_DEG * float(self.rng.uniform(0.8, 1.2))
        self._accum_lon += self.cfg.GRADUAL_RATE_DEG * float(self.rng.uniform(0.8, 1.2))
        self._accum_alt += self.cfg.GRADUAL_ALT_RATE * float(self.rng.uniform(0.5, 1.5))

        ep.lat += self._accum_lat
        ep.lon += self._accum_lon
        ep.alt += self._accum_alt

        # Subtle SNR manipulation
        for sat in ep.satellites:
            sat.snr_db_hz += float(self.rng.normal(1.0, 1.0))
            sat.carrier_phase_cycles += float(self.rng.normal(0.0, 0.05)) * (self._accum_lat / self.cfg.GRADUAL_RATE_DEG)

        ep.pdop = np.clip(ep.pdop + float(self.rng.normal(0.2, 0.1)) * (self._accum_lat / self.cfg.GRADUAL_RATE_DEG), 1.0, 15.0)
        ep.label = "SPOOFING"
        return ep


# ──────────────────────────────────────────────
# High-level interface
# ──────────────────────────────────────────────
class SpoofingSimulator:
    """
    Wraps all spoofing modes and applies them to epoch lists.

    Parameters
    ----------
    mode : str
        One of 'meaconing', 'false_position', 'gradual', 'mixed'.
    seed : int
    """

    MODES = ("meaconing", "false_position", "gradual", "mixed")

    def __init__(self, mode: str = "mixed", seed: int = 7, cfg: Optional[SpoofingConfig] = None):
        if mode not in self.MODES:
            raise ValueError(f"mode must be one of {self.MODES}")
        self.mode   = mode
        self.rng    = np.random.default_rng(seed)
        self.cfg    = cfg or SpoofingConfig()
        self._grad  = GradualSpoofer(cfg=self.cfg, seed=seed + 1)

    def attack(self, epoch: GNSSEpoch) -> GNSSEpoch:
        """Apply the configured spoofing mode to a single epoch."""
        if self.mode == "meaconing":
            return _inject_meaconing(epoch, self.rng, self.cfg)
        elif self.mode == "false_position":
            return _inject_false_position(epoch, self.rng, self.cfg)
        elif self.mode == "gradual":
            return self._grad.inject(epoch)
        else:  # mixed: randomly choose each epoch
            choice = self.rng.choice(["meaconing", "false_position", "gradual"])
            if choice == "meaconing":
                return _inject_meaconing(epoch, self.rng, self.cfg)
            elif choice == "false_position":
                return _inject_false_position(epoch, self.rng, self.cfg)
            else:
                return self._grad.inject(epoch)

    def generate_dataset(self, base_epochs: List[GNSSEpoch]) -> List[GNSSEpoch]:
        """Apply spoofing attacks to a list of clean epochs."""
        return [self.attack(ep) for ep in base_epochs]
