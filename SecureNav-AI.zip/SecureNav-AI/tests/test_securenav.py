"""
tests/test_securenav.py
───────────────────────
Unit and integration tests for SecureNav AI.

Test groups
───────────
  TestGNSSSimulator        – epoch structure, field ranges, dataset size
  TestSpoofingSimulator    – label injection, position deviation, SNR change
  TestJammingSimulator     – SNR drop, satellite loss, PDOP rise
  TestDriftSimulator       – accumulated drift, label, pseudorange growth
  TestFeatureExtraction    – column count, no NaN in critical cols, shape
  TestModelTraining        – pipeline fit/predict, feature importance shape
  TestAnomalyDetection     – fit/predict API, score range [0,1]
  TestEvaluation           – metric keys, confusion matrix shape
  TestAlertSystem          – alert generation, severity logic, batch processing
  TestEndToEnd             – mini pipeline smoke test
"""

import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

warnings.filterwarnings("ignore")

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from src.gnss_simulator     import GNSSSimulator, GNSSEpoch, epochs_to_dataframe
from src.spoofing_simulator import SpoofingSimulator
from src.jamming_simulator  import JammingSimulator
from src.drift_simulator    import DriftSimulator
from src.feature_extraction import (
    extract_features, extract_epoch_features,
    FEATURE_COLUMNS, CLASS_NAMES,
)
from src.model_training     import (
    build_random_forest, build_svm, build_mlp,
    prepare_data, train_model, get_feature_importances,
)
from src.anomaly_detection  import (
    AnomalyDetector, PositionDriftAnalyser,
    fit_anomaly_detector_from_df, ensemble_anomaly_score,
)
from src.evaluation         import compute_metrics, compute_roc, compare_models
from src.alert_system       import (
    AlertGenerator, process_batch, alert_summary,
    SEVERITY_INFO, SEVERITY_WARNING, SEVERITY_CRITICAL,
)


# ──────────────────────────────────────────────────────────────
# Shared fixtures
# ──────────────────────────────────────────────────────────────
N_SMALL = 80   # keep tests fast

@pytest.fixture(scope="module")
def normal_epochs():
    sim = GNSSSimulator(seed=1)
    return sim.generate_dataset(N_SMALL)


@pytest.fixture(scope="module")
def spoofed_epochs(normal_epochs):
    spoofer = SpoofingSimulator(mode="mixed", seed=2)
    return spoofer.generate_dataset(normal_epochs)


@pytest.fixture(scope="module")
def jammed_epochs(normal_epochs):
    jammer = JammingSimulator(mode="mixed", seed=3)
    return jammer.generate_dataset(normal_epochs)


@pytest.fixture(scope="module")
def drifted_epochs(normal_epochs):
    drifter = DriftSimulator(mode="mixed", seed=4)
    return drifter.generate_dataset(normal_epochs)


@pytest.fixture(scope="module")
def all_epochs(normal_epochs, spoofed_epochs, jammed_epochs, drifted_epochs):
    return normal_epochs + spoofed_epochs + jammed_epochs + drifted_epochs


@pytest.fixture(scope="module")
def feature_df(all_epochs):
    return extract_features(all_epochs)


@pytest.fixture(scope="module")
def prepared_data(feature_df):
    return prepare_data(feature_df, seed=42)


# ──────────────────────────────────────────────────────────────
# TestGNSSSimulator
# ──────────────────────────────────────────────────────────────
class TestGNSSSimulator:

    def test_epoch_count(self, normal_epochs):
        assert len(normal_epochs) == N_SMALL

    def test_epoch_type(self, normal_epochs):
        assert all(isinstance(e, GNSSEpoch) for e in normal_epochs)

    def test_label_is_normal(self, normal_epochs):
        assert all(e.label == "NORMAL" for e in normal_epochs)

    def test_satellite_count_range(self, normal_epochs):
        for ep in normal_epochs:
            assert 4 <= len(ep.satellites) <= 14, \
                f"Unexpected satellite count: {len(ep.satellites)}"

    def test_snr_positive(self, normal_epochs):
        for ep in normal_epochs:
            for s in ep.satellites:
                assert s.snr_db_hz > 0, "SNR must be positive"

    def test_pdop_range(self, normal_epochs):
        for ep in normal_epochs:
            assert 1.0 <= ep.pdop <= 25.0, f"PDOP out of range: {ep.pdop}"

    def test_timestamps_increasing(self, normal_epochs):
        ts = [e.timestamp for e in normal_epochs]
        assert all(ts[i] < ts[i+1] for i in range(len(ts)-1))

    def test_to_dataframe(self, normal_epochs):
        df = epochs_to_dataframe(normal_epochs)
        assert len(df) == N_SMALL
        assert "lat" in df.columns
        assert "snr_mean" in df.columns


# ──────────────────────────────────────────────────────────────
# TestSpoofingSimulator
# ──────────────────────────────────────────────────────────────
class TestSpoofingSimulator:

    def test_label(self, spoofed_epochs):
        assert all(e.label == "SPOOFING" for e in spoofed_epochs)

    def test_count(self, spoofed_epochs):
        assert len(spoofed_epochs) == N_SMALL

    def test_modes(self, normal_epochs):
        """Each explicit mode should run without error."""
        for mode in ("meaconing", "false_position", "gradual"):
            sp = SpoofingSimulator(mode=mode, seed=99)
            result = sp.generate_dataset(normal_epochs[:5])
            assert len(result) == 5
            assert all(e.label == "SPOOFING" for e in result)

    def test_position_deviation(self, normal_epochs, spoofed_epochs):
        """False-position spoofing should shift lat/lon noticeably."""
        sp = SpoofingSimulator(mode="false_position", seed=5)
        spoofed = sp.generate_dataset(normal_epochs[:20])
        lat_deltas = [abs(s.lat - n.lat) for s, n in zip(spoofed, normal_epochs[:20])]
        assert max(lat_deltas) > 1e-4, "False position should shift lat significantly"


# ──────────────────────────────────────────────────────────────
# TestJammingSimulator
# ──────────────────────────────────────────────────────────────
class TestJammingSimulator:

    def test_label(self, jammed_epochs):
        assert all(e.label == "JAMMING" for e in jammed_epochs)

    def test_snr_lower_than_normal(self, normal_epochs, jammed_epochs):
        normal_snr = np.mean([
            np.mean([s.snr_db_hz for s in e.satellites]) for e in normal_epochs
        ])
        jammed_snr = np.mean([
            np.mean([s.snr_db_hz for s in e.satellites]) for e in jammed_epochs
            if e.satellites
        ])
        assert jammed_snr < normal_snr, \
            f"Jammed SNR ({jammed_snr:.1f}) should be lower than normal ({normal_snr:.1f})"

    def test_satellite_loss(self, normal_epochs, jammed_epochs):
        normal_sat = np.mean([len(e.satellites) for e in normal_epochs])
        jammed_sat = np.mean([len(e.satellites) for e in jammed_epochs])
        assert jammed_sat <= normal_sat + 2, "Jamming should not increase satellite count"

    def test_modes(self, normal_epochs):
        for mode in ("wideband", "narrowband", "sweep"):
            j = JammingSimulator(mode=mode, seed=88)
            result = j.generate_dataset(normal_epochs[:5])
            assert all(e.label == "JAMMING" for e in result)

    def test_pdop_increases(self, normal_epochs):
        """Wideband jamming (removes most sats) should raise PDOP."""
        j = JammingSimulator(mode="wideband", seed=7)
        jammed = j.generate_dataset(normal_epochs)
        mean_pdop_normal = np.mean([e.pdop for e in normal_epochs])
        mean_pdop_jammed = np.mean([e.pdop for e in jammed])
        assert mean_pdop_jammed >= mean_pdop_normal * 0.9   # allow some variance


# ──────────────────────────────────────────────────────────────
# TestDriftSimulator
# ──────────────────────────────────────────────────────────────
class TestDriftSimulator:

    def test_label(self, drifted_epochs):
        assert all(e.label == "DRIFT" for e in drifted_epochs)

    def test_modes(self, normal_epochs):
        for mode in ("multipath", "ionospheric", "tropospheric", "clock", "urban"):
            d = DriftSimulator(mode=mode, seed=77)
            result = d.generate_dataset(normal_epochs[:5])
            assert all(e.label == "DRIFT" for e in result)

    def test_clock_accumulates(self, normal_epochs):
        """Clock drift mode should produce monotonically increasing clock bias."""
        d = DriftSimulator(mode="clock", seed=11)
        drifted = d.generate_dataset(normal_epochs[:30])
        biases = [e.clock_bias_m for e in drifted]
        # Bias should be generally growing (not necessarily strictly monotone due to noise)
        assert biases[-1] > biases[0], "Clock bias should grow over time under clock drift"

    def test_reset(self, normal_epochs):
        """DriftSimulator.reset() should restart accumulation."""
        d = DriftSimulator(mode="ionospheric", seed=22)
        d.generate_dataset(normal_epochs[:10])
        iono_before = d._iono_delay_m
        d.reset()
        assert d._iono_delay_m < iono_before, "Reset should clear accumulated iono delay"


# ──────────────────────────────────────────────────────────────
# TestFeatureExtraction
# ──────────────────────────────────────────────────────────────
class TestFeatureExtraction:

    def test_shape(self, feature_df, all_epochs):
        assert len(feature_df) == len(all_epochs)

    def test_columns_present(self, feature_df):
        for col in FEATURE_COLUMNS:
            assert col in feature_df.columns, f"Missing feature column: {col}"

    def test_label_column(self, feature_df):
        assert "label" in feature_df.columns
        assert set(feature_df["label"].unique()).issubset(set(CLASS_NAMES))

    def test_no_nan_in_key_features(self, feature_df):
        key_cols = ["snr_mean", "pdop", "num_satellites", "clock_bias"]
        for col in key_cols:
            assert feature_df[col].isna().sum() == 0, f"NaN found in {col}"

    def test_snr_mean_range(self, feature_df):
        normal_snr = feature_df.loc[feature_df["label"] == "NORMAL", "snr_mean"]
        assert normal_snr.mean() > 25.0, "Normal SNR mean should be above 25 dB-Hz"

    def test_differential_features(self, all_epochs):
        """pos_jump at epoch 0 should be 0."""
        df = extract_features(all_epochs[:10])
        assert df["pos_jump"].iloc[0] == 0.0

    def test_single_epoch(self, normal_epochs):
        feats = extract_epoch_features(normal_epochs[0])
        assert "snr_mean" in feats
        assert "label" in feats
        assert feats["label"] == "NORMAL"


# ──────────────────────────────────────────────────────────────
# TestModelTraining
# ──────────────────────────────────────────────────────────────
class TestModelTraining:

    @pytest.mark.parametrize("builder", [build_random_forest, build_svm, build_mlp])
    def test_fit_predict(self, builder, prepared_data):
        X, y, le = prepared_data
        pipe = builder(seed=42)
        pipe.fit(X[:60], y[:60])
        preds = pipe.predict(X[60:])
        assert len(preds) == len(X[60:])
        assert all(p in range(len(le.classes_)) for p in preds)

    def test_feature_importance_rf(self, prepared_data):
        X, y, le = prepared_data
        pipe = build_random_forest(seed=42)
        pipe.fit(X, y)
        imp = get_feature_importances(pipe)
        assert len(imp) == len(FEATURE_COLUMNS)
        assert imp.sum() == pytest.approx(1.0, abs=0.01)

    def test_feature_importance_svm_empty(self, prepared_data):
        X, y, le = prepared_data
        pipe = build_svm(seed=42)
        pipe.fit(X, y)
        imp = get_feature_importances(pipe)
        assert isinstance(imp, pd.Series)
        assert len(imp) == 0   # SVM doesn't expose feature_importances_

    def test_predict_proba(self, prepared_data):
        X, y, le = prepared_data
        for builder in [build_random_forest, build_svm, build_mlp]:
            pipe = builder(seed=42)
            pipe.fit(X[:60], y[:60])
            if hasattr(pipe, "predict_proba"):
                proba = pipe.predict_proba(X[60:])
                assert proba.shape[1] == len(le.classes_)
                assert np.allclose(proba.sum(axis=1), 1.0, atol=1e-5)


# ──────────────────────────────────────────────────────────────
# TestAnomalyDetection
# ──────────────────────────────────────────────────────────────
class TestAnomalyDetection:

    def test_fit_predict(self, prepared_data):
        X, y, le = prepared_data
        normal_mask = y == list(le.classes_).index("NORMAL")
        X_normal = X[normal_mask]
        det = AnomalyDetector(seed=42)
        det.fit(X_normal)
        preds = det.predict(X)
        assert set(preds).issubset({1, -1})

    def test_score_range(self, prepared_data):
        X, y, le = prepared_data
        normal_mask = y == list(le.classes_).index("NORMAL")
        det = AnomalyDetector(seed=42)
        det.fit(X[normal_mask])
        scores = det.score_samples(X)
        assert scores.min() >= 0.0 - 1e-9
        assert scores.max() <= 1.0 + 1e-9

    def test_unfitted_raises(self):
        det = AnomalyDetector()
        with pytest.raises(RuntimeError, match="must be fitted"):
            det.predict(np.zeros((5, len(FEATURE_COLUMNS))))

    def test_position_drift_analyser(self):
        rng = np.random.default_rng(0)
        normal_jumps = rng.normal(1.0, 0.5, size=200)
        pda = PositionDriftAnalyser(window=10, threshold=5.0)
        pda.fit(normal_jumps)
        # Inject obvious anomalies
        anomalous = np.concatenate([normal_jumps[:50],
                                    rng.normal(50.0, 5.0, size=20),
                                    normal_jumps[50:]])
        flags = pda.detect(anomalous)
        assert flags[50:70].any(), "Should detect drift in anomalous segment"

    def test_ensemble_score_range(self, prepared_data):
        X, y, le = prepared_data
        n = len(X)
        n_cls = len(le.classes_)
        fake_probs   = np.random.dirichlet(np.ones(n_cls), size=n)
        fake_anomaly = np.random.uniform(0, 1, size=n)
        ens = ensemble_anomaly_score(fake_probs, fake_anomaly, normal_class_idx=0)
        assert ens.min() >= 0.0
        assert ens.max() <= 1.0 + 1e-9

    def test_fit_from_df(self, feature_df):
        det = fit_anomaly_detector_from_df(feature_df, seed=42)
        X = feature_df[FEATURE_COLUMNS].fillna(0).values
        scores = det.score_samples(X)
        assert len(scores) == len(feature_df)


# ──────────────────────────────────────────────────────────────
# TestEvaluation
# ──────────────────────────────────────────────────────────────
class TestEvaluation:

    def test_compute_metrics_keys(self):
        y_true = np.array([0, 1, 2, 3, 0, 1, 2, 3])
        y_pred = np.array([0, 1, 2, 3, 0, 0, 2, 3])
        m = compute_metrics(y_true, y_pred)
        for key in ("accuracy", "macro_f1", "weighted_f1", "confusion_matrix",
                    "report_str", "per_class"):
            assert key in m, f"Missing key: {key}"

    def test_accuracy_range(self):
        y_true = np.array([0, 1, 2, 0, 1, 2])
        y_pred = np.array([0, 1, 2, 0, 1, 2])
        m = compute_metrics(y_true, y_pred)
        assert m["accuracy"] == pytest.approx(1.0)

    def test_confusion_matrix_shape(self):
        y_true = np.array([0, 1, 2, 3])
        y_pred = np.array([0, 1, 3, 2])
        m = compute_metrics(y_true, y_pred)
        assert m["confusion_matrix"].shape == (4, 4)

    def test_compute_roc(self):
        rng    = np.random.default_rng(0)
        y_true = np.array([0, 1, 2, 3] * 20)
        y_prob = rng.dirichlet(np.ones(4), size=80)
        roc = compute_roc(y_true, y_prob)
        assert set(roc.keys()) == set(CLASS_NAMES)
        for cls, data in roc.items():
            assert 0.0 <= data["auc"] <= 1.0

    def test_compare_models(self):
        results = {
            "model_a": {"accuracy": 0.95, "macro_f1": 0.94, "weighted_f1": 0.95,
                        "macro_precision": 0.94, "macro_recall": 0.94},
            "model_b": {"accuracy": 0.90, "macro_f1": 0.89, "weighted_f1": 0.90,
                        "macro_precision": 0.89, "macro_recall": 0.89},
        }
        df = compare_models(results)
        assert df.iloc[0]["model"] == "model_a"   # best first
        assert len(df) == 2


# ──────────────────────────────────────────────────────────────
# TestAlertSystem
# ──────────────────────────────────────────────────────────────
class TestAlertSystem:

    def test_critical_spoofing_alert(self):
        gen = AlertGenerator(cooldown_s=0)
        row = pd.Series({
            "lat": 37.77, "lon": -122.41, "alt": 10.0,
            "num_satellites": 8, "snr_mean": 42.0,
            "pdop": 2.1, "pos_jump": 1500.0,
            "jamming_score": 0.1, "spoofing_score": 0.9,
            "snr_min": 35.0, "clock_bias": 250.0,
            "timestamp": 0.0,
        })
        alert = gen.generate("SPOOFING", confidence=0.95, anomaly_score=0.75,
                             ensemble_score=0.88, row=row)
        assert alert is not None
        assert alert.severity == SEVERITY_CRITICAL
        assert alert.threat_class == "SPOOFING"

    def test_normal_info_alert(self):
        gen = AlertGenerator(cooldown_s=0, min_severity=SEVERITY_INFO)
        row = pd.Series({"lat": 0, "lon": 0, "alt": 0,
                         "num_satellites": 9, "snr_mean": 42.0,
                         "pdop": 1.8, "pos_jump": 0.3,
                         "jamming_score": 0.0, "spoofing_score": 0.0,
                         "snr_min": 38.0, "clock_bias": 2.0,
                         "timestamp": 0.0})
        alert = gen.generate("NORMAL", confidence=0.99, anomaly_score=0.05,
                             ensemble_score=0.04, row=row)
        assert alert is not None
        assert alert.severity == SEVERITY_INFO

    def test_min_severity_filter(self):
        gen = AlertGenerator(cooldown_s=0, min_severity=SEVERITY_CRITICAL)
        row = pd.Series({"lat": 0, "lon": 0, "alt": 0,
                         "num_satellites": 7, "snr_mean": 30.0,
                         "pdop": 3.0, "pos_jump": 5.0,
                         "jamming_score": 0.3, "spoofing_score": 0.3,
                         "snr_min": 25.0, "clock_bias": 5.0,
                         "timestamp": 0.0})
        alert = gen.generate("JAMMING", confidence=0.55, anomaly_score=0.30,
                             ensemble_score=0.45, row=row)
        assert alert is None   # WARNING filtered out

    def test_batch_processing(self, prepared_data, feature_df):
        X, y, le = prepared_data
        pipe = build_random_forest(seed=42)
        pipe.fit(X, y)
        y_pred = pipe.predict(X[:20])
        y_prob = pipe.predict_proba(X[:20])
        anom   = np.random.default_rng(0).uniform(0, 1, 20)
        ens    = ensemble_anomaly_score(y_prob, anom)
        gen    = AlertGenerator(cooldown_s=0)
        alerts = process_batch(
            predictions=y_pred, probabilities=y_prob,
            anomaly_scores=anom, ensemble_scores=ens,
            feature_df=feature_df.head(20).reset_index(drop=True),
            class_names=list(le.classes_),
            generator=gen, verbose=False,
        )
        assert isinstance(alerts, list)

    def test_alert_summary_structure(self):
        gen = AlertGenerator(cooldown_s=0)
        row = pd.Series({"lat": 0, "lon": 0, "alt": 0,
                         "num_satellites": 6, "snr_mean": 18.0,
                         "pdop": 8.0, "pos_jump": 0.0,
                         "jamming_score": 0.8, "spoofing_score": 0.1,
                         "snr_min": 12.0, "clock_bias": 5.0,
                         "timestamp": 0.0})
        gen.generate("JAMMING", 0.92, 0.65, 0.82, row)
        summary = alert_summary(gen.get_history())
        assert not summary.empty
        assert "threat_class" in summary.columns
        assert "count" in summary.columns


# ──────────────────────────────────────────────────────────────
# TestEndToEnd — mini smoke test
# ──────────────────────────────────────────────────────────────
class TestEndToEnd:

    def test_mini_pipeline(self):
        """
        Full pipeline from raw simulation → prediction.
        Uses only 40 epochs per class for speed.
        """
        N = 40
        # Generate
        sim = GNSSSimulator(seed=0)
        eps_n = sim.generate_dataset(N)
        eps_s = SpoofingSimulator(seed=1).generate_dataset(
                    GNSSSimulator(seed=10).generate_dataset(N))
        eps_j = JammingSimulator(seed=2).generate_dataset(
                    GNSSSimulator(seed=20).generate_dataset(N))
        eps_d = DriftSimulator(seed=3).generate_dataset(
                    GNSSSimulator(seed=30).generate_dataset(N))

        # Features
        df = extract_features(eps_n + eps_s + eps_j + eps_d)
        assert len(df) == N * 4
        assert "label" in df.columns

        # Prepare & train
        X, y, le = prepare_data(df, seed=0)
        pipe = build_random_forest(n_estimators=50, seed=0)
        pipe = train_model(pipe, X, y)

        # Predict
        preds = pipe.predict(X)
        assert len(preds) == len(y)

        # Evaluate
        m = compute_metrics(y, preds, class_names=le.classes_.tolist())
        assert m["accuracy"] > 0.5, "Mini pipeline accuracy should exceed 50%"

        # Anomaly detector
        det = fit_anomaly_detector_from_df(df, seed=0)
        scores = det.score_samples(X)
        assert len(scores) == len(X)
        assert 0.0 <= scores.min() and scores.max() <= 1.0 + 1e-9

        print(f"\n  [smoke test] accuracy={m['accuracy']:.3f}  ✓")
