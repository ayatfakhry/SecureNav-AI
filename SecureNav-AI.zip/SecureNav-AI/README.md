# SecureNav AI 🛰️
### AI-Based GNSS Spoofing and Jamming Detection System

![Python](https://img.shields.io/badge/Python-3.9%2B-blue?style=flat-square&logo=python)
![scikit-learn](https://img.shields.io/badge/scikit--learn-1.3%2B-orange?style=flat-square)
![License](https://img.shields.io/badge/License-MIT-green?style=flat-square)
![Research](https://img.shields.io/badge/Level-Research%20Grade-red?style=flat-square)

---

## Overview

**SecureNav AI** is a research-grade machine learning system designed to detect GNSS (Global Navigation Satellite System) attacks in real time. It classifies four distinct signal states:

| Class | Description |
|-------|-------------|
| `NORMAL` | Clean, trusted GNSS signal |
| `SPOOFING` | Forged GPS signals misleading the receiver |
| `JAMMING` | Radio frequency interference blocking signals |
| `DRIFT` | Gradual position drift / multipath anomaly |

The system combines supervised classification (Random Forest, SVM, MLP Neural Network) with unsupervised anomaly detection (Isolation Forest) to provide robust, multi-layer threat detection.

---

## Architecture

```
SecureNav-AI/
├── README.md                   # Project documentation
├── requirements.txt            # Python dependencies
├── main.py                     # Full pipeline entrypoint
├── data/                       # Generated synthetic datasets
├── src/
│   ├── gnss_simulator.py       # Simulates clean GNSS signals
│   ├── spoofing_simulator.py   # Simulates spoofing attacks
│   ├── jamming_simulator.py    # Simulates jamming attacks
│   ├── feature_extraction.py   # Derives ML-ready features
│   ├── model_training.py       # Trains RF / SVM / MLP classifiers
│   ├── anomaly_detection.py    # Isolation Forest anomaly detection
│   ├── evaluation.py           # Metrics, confusion matrix, reports
│   └── visualization.py        # Plots and dashboard
├── scripts/
│   └── run_detection.py        # CLI detection script
├── results/                    # Output plots and reports
└── tests/                      # Unit and integration tests
```

---

## Features

- **Synthetic Data Generation**: Realistic GNSS signal simulation with configurable noise, satellite geometry, and attack injection.
- **Multi-Attack Simulation**: Spoofing (meaconing, false position injection), jamming (wideband, narrowband, sweep), and position drift.
- **Rich Feature Extraction**: 20+ features including SNR statistics, position jump magnitude, carrier phase residuals, PDOP, clock bias, velocity anomalies.
- **Ensemble Classification**: Random Forest, SVM (RBF kernel), and MLP Neural Network with cross-validation.
- **Anomaly Detection**: Unsupervised Isolation Forest as a second detection layer.
- **Full Evaluation Suite**: Accuracy, precision, recall, F1-score per class, macro/weighted averages, confusion matrix heatmap.
- **Visualization Dashboard**: Signal plots, feature importance, PCA scatter, ROC curves, position trajectory maps.

---

## Quickstart

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Run Full Pipeline
```bash
python main.py
```

### 3. Run Detection Script (CLI)
```bash
python scripts/run_detection.py --samples 5000 --model rf --plot
```

### 4. Run Tests
```bash
python -m pytest tests/ -v
```

---

## Model Performance (Typical Results)

| Model | Accuracy | F1 (macro) |
|-------|----------|------------|
| Random Forest | ~98.5% | ~0.985 |
| SVM (RBF) | ~96.2% | ~0.961 |
| MLP Neural Network | ~97.8% | ~0.977 |

*Results vary per synthetic seed. Run `main.py` for your environment's metrics.*

---

## Signal Features Used

| Feature | Description |
|---------|-------------|
| `snr_mean` | Mean Signal-to-Noise Ratio across satellites |
| `snr_std` | SNR standard deviation |
| `snr_min` | Minimum SNR (jamming indicator) |
| `position_jump` | Euclidean position change per epoch |
| `velocity_magnitude` | Derived velocity magnitude |
| `carrier_phase_residual` | Phase measurement error |
| `pdop` | Position Dilution of Precision |
| `clock_bias` | Receiver clock offset |
| `num_satellites` | Visible satellite count |
| `cn0_drop_rate` | Rate of C/N0 degradation |
| ... | 20+ total features |

---

## Attack Simulation Details

### Spoofing
- **Meaconing**: Relay and re-broadcast authentic signals with delay
- **False Position Injection**: Craft signals placing receiver at attacker-chosen location
- Gradual position deviation to avoid detection thresholds

### Jamming
- **Wideband Noise**: Broadband RF interference raising noise floor
- **Narrowband CW**: Continuous wave interference on L1/L2
- **Sweep Jamming**: Frequency-swept interference pattern
- Manifests as SNR collapse and satellite count drop

### Drift Anomaly
- Multipath-induced position errors
- Ionospheric/tropospheric delay buildup
- Gradual clock drift accumulation

---

## Research Extensions

- Integration with real GNSS receiver logs (NMEA / RINEX format)
- Deep learning models (LSTM for temporal pattern detection)
- Real-time streaming detection with Kafka
- Multi-constellation analysis (GPS + GLONASS + Galileo)
- Federated learning across distributed receiver networks

---

## References

1. Humphreys, T.E. et al. (2012). "The Texas Spoofing Test Battery." *ION GNSS+*
2. Psiaki, M.L. & Humphreys, T.E. (2016). "GNSS Spoofing and Detection." *Proceedings of the IEEE*
3. Scikit-learn: Machine Learning in Python. *JMLR 12*, pp. 2825-2830, 2011.
4. Liu, F.T., Ting, K.M., Zhou, Z.H. (2008). "Isolation Forest." *ICDM*

---

## License

MIT License © 2024 SecureNav AI Research Project
